## To compile
To run solution
- install pandas and numpy
- run, python solution.py
- will create new final.csv file with zipcode,rate